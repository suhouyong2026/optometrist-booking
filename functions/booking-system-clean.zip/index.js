exports.main = async (event, context) => {
  console.log('收到请求:', JSON.stringify(event));
  
  return {
    statusCode: 200,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    },
    body: {
      success: true,
      message: '云函数测试成功',
      event: event
    };
  };
